package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;

import com.cg.ibs.cardmanagement.JPAUtil.JpaUtilImpl;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CreditCardStatus;
import com.cg.ibs.cardmanagement.bean.CustomerBean;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class CreditCardDaoImpl implements CreditCardDao {
	private static Logger logger = Logger.getLogger(CreditCardDaoImpl.class);
	private EntityManager entityManager;
	private EntityTransaction entityTransaction;

	public CreditCardDaoImpl() {
		entityManager = JpaUtilImpl.getEntityManger();
		entityTransaction = JpaUtilImpl.getTransaction();
	}

	public List<CreditCardBean> viewAllCreditCards() throws IBSException {
		logger.info("entered into viewAllCreditCards method of CreditCardDaoImpl class");

		TypedQuery<CreditCardBean> creditQuery = entityManager.createQuery(SqlQueries.SELECT_DATA_FROM_CREDIT_CARD,
				CreditCardBean.class);
		List<CreditCardBean> creditCards = creditQuery.getResultList();

		return creditCards;

	}

	@Override
	public boolean verifyCreditCardNumber(BigInteger creditCardNumber) throws IBSException {
		logger.info("entered into verifyCreditCardNumber method of CreditCardDaoImpl class");
		boolean result = false;

		CreditCardBean d = entityManager.find(CreditCardBean.class, creditCardNumber);

		if (d != null)
			result = true;

		return result;
	}

	@Override
	public void setNewCreditPin(BigInteger creditCardNumber, String newPin) throws IBSException {
		logger.info("entered into setNewCreditPin method of CreditCardDaoImpl class");
		CreditCardBean cardBean = entityManager.find(CreditCardBean.class, creditCardNumber);
		cardBean.setCurrentPin(newPin);

	}

	@Override
	public String getCreditCardPin(BigInteger creditCardNumber) throws IBSException {
		logger.info("entered into getCreditCardPin method of CreditCardDaoImpl class");

		TypedQuery<String> query = entityManager
				.createQuery("select c.currentPin from CreditCardBean c where cardNumber=:creditCardNum", String.class);
		query.setParameter("creditCardNum", creditCardNumber);
		return query.getSingleResult();

	}

	@Override
	public BigInteger getCreditUci(BigInteger creditCardNumber) throws IBSException {
		logger.info("entered into getCreditUci method of CreditCardDaoImpl class");
		TypedQuery<BigInteger> query = entityManager.createQuery(
				"select d.UCI from CreditCardBean c join  c. customerBeanObject d where c.cardNumber=:creditCardNum",
				BigInteger.class);
		query.setParameter("creditCardNum", creditCardNumber);

		return query.getSingleResult();

	}

	@Override
	public String getcreditCardType(BigInteger creditCardNumber) throws IBSException {
		logger.info("entered into getCreditCardType method of CreditCardDaoImpl class");

		TypedQuery<String> query = entityManager
				.createQuery("select c.cardType from CreditCardBean c where c.cardNumber=:creditCardNum", String.class);
		query.setParameter("creditCardNum", creditCardNumber);

		return query.getSingleResult();
	}

	@Override
	public CreditCardStatus getCreditCardStatus(BigInteger creditCardNumber) throws IBSException {
		logger.info("entered into getCreditCardStatus method of CreditCardDaoImpl class");
		TypedQuery<CreditCardStatus> query = entityManager.createQuery(
				"select d.cardStatus from CreditCardBean d where d.cardNumber=:creditCardNum", CreditCardStatus.class);
		query.setParameter("creditCardNum", creditCardNumber);

		return query.getSingleResult();
	}

	@Override
	public void actionANCC(CreditCardBean bean1) throws IBSException {
		logger.info("entered into actionANCC method of CreditCardDaoImpl class");

		entityTransaction.begin();
		entityManager.persist(bean1);
		entityTransaction.commit();

	}

	@Override
	public void actionBlockCC(String queryId, CreditCardStatus status) throws IBSException {
		logger.info("entered into actionBlockCC method of CreditCardDaoImpl class");

		TypedQuery<BigInteger> query = entityManager
				.createQuery("select d.cardNumber from CaseIdBean d where d.caseIdTotal =:queryid", BigInteger.class);
		query.setParameter("queryid", queryId);
		BigInteger cardnum = query.getSingleResult();
		CreditCardBean cardBean = entityManager.find(CreditCardBean.class, cardnum);
		cardBean.setCardStatus(status);

	}

	@Override
	public void actionUpgradeCC(String queryId) throws IBSException {
		logger.info("entered into actionUpgradeCC method of CreditCardDaoImpl class");
		TypedQuery<CaseIdBean> query = entityManager
				.createQuery("select d from CaseIdBean d where d.caseIdTotal =:queryid", CaseIdBean.class);
		query.setParameter("queryid", queryId);
		CaseIdBean caseIdBean = query.getSingleResult();
		BigInteger cardNum = caseIdBean.getCardNumber();
		String type = caseIdBean.getDefineServiceRequest();
		CreditCardBean cardBean = entityManager.find(CreditCardBean.class, cardNum);
		cardBean.setCardType(type);

	}

}
